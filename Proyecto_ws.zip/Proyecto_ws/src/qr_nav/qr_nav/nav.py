import rclpy
from rclpy.node import Node
from geometry_msgs.msg import Twist
from std_msgs.msg import String, Float32
from geometry_msgs.msg import Point
import time


class QRMovementController(Node):
    def _init_(self):
        super()._init_('qr_movement_controller')

        # Suscripciones a los tópicos
        self.qr_code_subscription = self.create_subscription(
            String,
            '/qr/code',
            self.qr_code_callback,
            10
        )

        self.qr_pos_subscription = self.create_subscription(
            Point,
            '/qr/pos',
            self.qr_pos_callback,
            10
        )

        self.qr_size_subscription = self.create_subscription(
            Float32,
            '/qr/size',
            self.qr_size_callback,
            10
        )

        # Publicador al tópico /cmd_vel para controlar el robot
        self.cmd_vel_pub = self.create_publisher(Twist, '/cmd_vel', 10)

        # Variables para almacenar el estado actual
        self.qr_code = ""
        self.qr_pos = Point()
        self.qr_size = 0.0
        self.target_x = 290  # Centro objetivo en píxeles
        self.size_target = 168400 # Tamaño objetivo del QR

        self.get_logger().info("Nodo QRMovementController iniciado.")

        # Secuencia de acciones
        self.turn_180_degrees()
        self.send_twist(0.0, 0.0, 0.6)
        self.align_with_qr()
        self.send_twist(0.0, 0.0, 0.6)
        self.approach_qr()
        #self.perform_action_based_on_qr()

    def turn_180_degrees(self):
        """
        Realiza un giro inicial de 180 grados.
        """
        self.get_logger().info("Girando 180 grados al inicio.")
        self.send_twist(0.0, 1.0, 0.48)  # Ajusta la velocidad y duración según el robot 
        self.get_logger().info("Giro de 180 grados completado.")

    def align_with_qr(self):
        """
        Ajusta la orientación del robot para centrar el QR en el campo de visión.
        """
        self.get_logger().info("Esperando posición del QR para alinear.")
        while self.qr_pos.x == 0.0:  # Espera a recibir datos de posición
            rclpy.spin_once(self)

        error_x = self.target_x - self.qr_pos.x
        self.get_logger().info(f"Error respecto al centro: {error_x}")

        if abs(error_x) > 10:  # Tolerancia de 10 píxeles
            angular_z = 1 * error_x  # Constante proporcional simple
            angular_z = max(min(angular_z, 0.5), -0.5)  # Limitar el giro
            self.send_twist(0.0, angular_z, 0.5)  # Ajustar la duración según el error
            self.get_logger().info("QR alineado con el robot.")
        else:
            self.get_logger().info("QR ya está centrado.")

    def approach_qr(self):
        """
        Avanza hacia el QR hasta alcanzar el tamaño objetivo.
        """
        self.get_logger().info("Avanzando hacia el QR.")
        while self.qr_size < self.size_target:  # Espera a alcanzar el tamaño objetivo
            self.send_twist(0.6, 0.0, 3)
            rclpy.spin_once(self)
            error_x = self.target_x - self.qr_pos.x
            self.get_logger().info(f"Error respecto al centro: {error_x}")

            if abs(error_x) > 10:  # Tolerancia de 10 píxeles
                angular_z = 1 * error_x  # Constante proporcional simple
                angular_z = max(min(angular_z, 0.5), -0.5)  # Limitar el giro
                self.send_twist(0.0, angular_z, 0.5)  # Ajustar la duración según el error
                self.get_logger().info("QR alineado con el robot.")
            else:
            	self.get_logger().info("QR ya está centrado.")

        self.get_logger().info("Tamaño del QR alcanzado. Deteniendo avance.")
        self.send_twist(0.0, 0.0, 0.0)

    def perform_action_based_on_qr(self):
        """
        Realiza la acción basada en el código QR.
        """
        self.get_logger().info("Esperando código QR.")
        while not self.qr_code:  # Espera a recibir un código QR
            rclpy.spin_once(self)

        self.get_logger().info(f"Código QR detectado: {self.qr_code}")
        if self.qr_code == 'A1':
            self.get_logger().info("Acción: Girar 90 grados a la derecha.")
            self.send_twist(0.0, 1.0, 1.0)  # Ajusta la duración según el robot
        elif self.qr_code == 'B1':
            self.get_logger().info("Acción: Girar 90 grados a la izquierda.")
            self.send_twist(0.0, -1.0, 1.0)  # Ajusta la duración según el robot
        elif self.qr_code == 'C1':
            self.get_logger().info("Acción: Detener el movimiento.")
            self.send_twist(0.0, 0.0, 1.0)
        else:
            self.get_logger().info("Código QR desconocido, no se realizará acción.")

    def qr_code_callback(self, msg):
        self.qr_code = msg.data

    def qr_pos_callback(self, msg):
        self.qr_pos = msg

    def qr_size_callback(self, msg):
        self.qr_size = msg.data

    def send_twist(self, linear_x, angular_z, duration):
        """Publica un mensaje Twist de forma continua por un tiempo específico."""
        twist_msg = Twist()
        twist_msg.linear.x = linear_x
        twist_msg.angular.z = angular_z

        start_time = time.time()
        while time.time() - start_time <= duration:
            self.cmd_vel_pub.publish(twist_msg)
            time.sleep(0.01)  # Publicar cada 10 ms

        # Detener el robot después de la duración
        self.cmd_vel_pub.publish(Twist())


def main(args=None):
    rclpy.init(args=args)
    qr_movement_controller = QRMovementController()

    rclpy.spin(qr_movement_controller)

    qr_movement_controller.destroy_node()
    rclpy.shutdown()


if _name_ == '_main_':
    main()
