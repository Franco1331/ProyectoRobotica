import rclpy
from rclpy.node import Node
from geometry_msgs.msg import Twist
from std_msgs.msg import String, Float32
from geometry_msgs.msg import Point
import time


class QRMovementController(Node):
    def _init_(self):
        super()._init_('qr_movement_controller')

        # Suscripciones a los tópicos
        self.qr_code_subscription = self.create_subscription(
            String,
            '/qr/code',
            self.qr_code_callback,
            10
        )

        self.qr_pos_subscription = self.create_subscription(
            Point,
            '/qr/pos',
            self.qr_pos_callback,
            10
        )

        self.qr_size_subscription = self.create_subscription(
            Float32,
            '/qr/size',
            self.qr_size_callback,
            10
        )

        # Publicador al tópico /cmd_vel para controlar el robot
        self.cmd_vel_pub = self.create_publisher(Twist, '/cmd_vel', 10)

        # Variables para almacenar el estado actual
        self.qr_code = ""
        self.qr_pos = Point()
        self.qr_size = 0.0
        self.target_x = 290  # Centro objetivo en píxeles
        self.size_target = 168480  # Tamaño objetivo del QR

        self.get_logger().info("Nodo QRMovementController iniciado.")

        # Comienza con un giro de 180 grados
        self.turn_180_degrees()

    def qr_code_callback(self, msg):
        self.qr_code = msg.data
        self.get_logger().info(f"Código QR recibido: {self.qr_code}")

    def qr_pos_callback(self, msg):
        self.qr_pos = msg

        # Calcular error respecto al centro de la imagen
        error_x = self.target_x - self.qr_pos.x

        # Ajustar la orientación del robot para centrar el QR
        if abs(error_x) > 10:  # Tolerancia de 10 píxeles
            angular_z = 0.002 * error_x  # Constante proporcional simple
            angular_z = max(min(angular_z, 0.5), -0.5)  # Limitar el giro
            self.send_twist(0.0, angular_z, 0.1)
        else:
            self.get_logger().info("QR centrado.")

    def qr_size_callback(self, msg):
        self.qr_size = msg.data

        # Avanzar hacia el QR hasta alcanzar el tamaño objetivo
        if self.qr_size < self.size_target:
            self.get_logger().info(f"QR detectado, avanzando: tamaño actual {self.qr_size}")
            self.send_twist(0.2, 0.0, 0.1)  # Avanzar en línea recta
        else:
            self.get_logger().info("Tamaño del QR alcanzado. Deteniendo avance.")
            self.send_twist(0.0, 0.0, 0.0)

            # Realizar acción basada en el código QR
            self.execute_movement()

    def send_twist(self, linear_x, angular_z, duration):
        """Publica un mensaje Twist de forma continua por un tiempo específico."""
        twist_msg = Twist()
        twist_msg.linear.x = linear_x
        twist_msg.angular.z = angular_z

        # Publicar continuamente durante la duración especificada
        start_time = time.time()
        while time.time() - start_time <= duration:
            self.cmd_vel_pub.publish(twist_msg)
            time.sleep(0.01)  # Publicar cada 10 ms

        # Detener el robot después de la duración
        self.cmd_vel_pub.publish(Twist())

    def turn_180_degrees(self):
        """
        Realiza un giro inicial de 180 grados.
        """
        self.get_logger().info("Girando 180 grados al inicio.")
        self.send_twist(0.0, 0.5, 1.2)  # Ajusta la velocidad y duración según el robot
        self.get_logger().info("Giro de 180 grados completado.")

    def execute_movement(self):
        """
        Realiza la acción en función del código QR recibido.
        """
        if self.qr_code == 'A1':
            self.get_logger().info("Acción: Girar 90 grados a la derecha")
            self.send_twist(0.0, 1.0, 1.0)  # Ajusta la duración según el robot
        elif self.qr_code == 'B1':
            self.get_logger().info("Acción: Girar 90 grados a la izquierda")
            self.send_twist(0.0, -1.0, 1.0)  # Ajusta la duración según el robot
        elif self.qr_code == 'C1':
            self.get_logger().info("Acción: Detener el movimiento")
            self.send_twist(0.0, 0.0, 1.0)
        else:
            self.get_logger().info("Código QR desconocido, no se realizará acción.")


def main(args=None):
    rclpy.init(args=args)
    qr_movement_controller = QRMovementController()

    rclpy.spin(qr_movement_controller)

    qr_movement_controller.destroy_node()
    rclpy.shutdown()


if _name_ == '_main_':
    main()
